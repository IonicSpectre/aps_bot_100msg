#!/bin/bash
python bot.py
